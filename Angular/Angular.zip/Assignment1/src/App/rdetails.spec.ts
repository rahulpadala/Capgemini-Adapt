import { Rdetails } from './rdetails';

describe('Rdetails', () => {
  it('should create an instance', () => {
    expect(new Rdetails()).toBeTruthy();
  });
});
