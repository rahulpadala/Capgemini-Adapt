export class Mdetails {

        constructor(public name:string,public item1:string,public item2:string,public item3:string){}
        
        }
        
