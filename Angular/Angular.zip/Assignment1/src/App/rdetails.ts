export class Rdetails {

constructor(public name:string){}

}
