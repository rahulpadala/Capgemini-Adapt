export class User {
   constructor(
       public id:any,
    public name:any,
   public  category:any,
    public description:any){}
}
